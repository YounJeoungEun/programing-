//file: add.c

#include<stdio.h>

int main(void)
{
	int num1 = 30, num2 = 30;

	printf("num1 + num2�� ��� ��: %d\n", num1 + num2);

	getchar();
	return 0;
}