#include<stdio.h>
int main(void)
{
	const int MAX = 6;
	int i, j;

	for (i = 1; i <= MAX; i++)
	{
		for (j = 1; j <= i; j++)
			printf("*");
		puts("");
	}
	for (i=MAX-1; i>=1; i--)
	{
		for (j=i; j>=1; j--)
			printf("*");
		puts("");
	}

	getchar();
	return 0;
}