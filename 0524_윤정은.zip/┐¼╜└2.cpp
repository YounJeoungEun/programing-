#include<stdio.h>

int intpower(int m, int n);

int main(void)
{
	int m, n, y;
	printf("���� 2�� �Է�: ");
	scanf_s("%d %d", &m, &n);
	y=intpower(m, n);
	printf("%d�� %d������ %d�Դϴ�.\n", m, n, intpower(m,n));

	getchar(); getchar();
	return 0;
}
int intpower(int m, int n)
{
	int i=1, y=1;
	
	for (i = 1; i <= n; i++)
		y = y*m;

	return y;
}