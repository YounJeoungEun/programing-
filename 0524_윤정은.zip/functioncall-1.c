#include<stdio.h>

int add2(int a, int b);       //int add2(int, int)�� ����
int findMax2(int, int);       //int findMax2(int a, int b)�� ����
int findMin2(int, int);


int main(void)
{
	int a = 3, b = 5;

	int max = findMax2(a, b);
	int min = findMin2(a, b);
	int sum = add2(a, b);
	printf("�ִ�: %d\n", max);
	printf("�ּ�: %d\n", min);
	printf("��: %d\n", sum);
	
	getchar();

	return 0;
}

int add2(int a, int b)
{
	int sum = a + b;

	return (sum);
}

int findMax2(int a, int b)
{
	int max = a > b ? a : b;

	return max;
}

int findMin2(int x, int y)
{
	int min = x < y ? x : y;

	return (min);
}


void printMin(int a, int b)
{
	int min = a < b ? a : b;
	printf("�ּ�:%d\n", min);

	return;        //���� ����
}