//file: subtraction.c

#include<stdio.h>

int main(void)
{
	int num1 = 30, num2 = 14;
	int difference;

	difference = num1 - num2;
	printf("num1 - num2 �� ���: %d\n", difference);

	getchar();
	return 0;
}