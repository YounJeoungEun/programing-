//file: putchar.c

#include<stdio.h>

int main(void)
{
	char a = '\0';

	puts("���� �ϳ� �Է�");
	a = getchar();
	putchar(a); putchar('\n');

	getchar();
	getchar();
	return 0;

}